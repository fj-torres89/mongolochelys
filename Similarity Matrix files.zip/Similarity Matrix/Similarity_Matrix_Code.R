## CODE FOR SIMILARITY MATRIX

# The object "Similarity_matrix.txt" is the same matrix as used for the phylogenetic analyses in Evers & Benson (2018).
# However, polymorphisms have been removed and replaced by "?" in "Similarity_matrix.txt", and taxa have been re-arranged
# to mirror the phylogenetic results of the unordered analysis (Evers & Benson 2018: Fig. 4A) to facilitate an easier
# reading of the similarity matrices produced.

# Load character-taxon matrix 

data.matrix<-read.table("Similarity_matrix.txt", header=T, na.strings=c("-","?"))

# Transpose matrix

data.matrix<-t(data.matrix)

# Make a matrix of same dimensions is which the entries are numerical

data2<-matrix(nrow=dim(data.matrix)[1],ncol=dim(data.matrix)[2])
for(i in 1:ncol(data.matrix)) data2[,i]<-as.numeric(data.matrix[,i])
colnames(data2)<-colnames(data.matrix)

# Create a dissimilarity matrix based on 'data2' with taxa in numeric columns

sim.data<-matrix(nrow=ncol(data2),ncol=ncol(data2))
rownames(sim.data)<-colnames(data2)
colnames(sim.data)<-colnames(data2)

# Calculate dissmilarity values

for(i in 1:ncol(data2)) {for(j in 1:ncol(data2)) {sim.data[j,i]<-length(grep(TRUE,data2[,j]==data2[,i]))/length(grep(TRUE,complete.cases(data2[,j]==data2[,i])))}}

# PLOTTING THE DISTANCE MATRIX AS A HEATMAP

	# Load required packages for coloring matrices 
	
	install.packages("gclus")
	require(gclus)

	# Load packages for additional colors
	
	library(RColorBrewer)
	display.brewer.all(type="seq")

	# Assign colours to the similarity matrix (because the colour scheme works better in the inverse order, the data is transformed to a dissimilarity matrix)
	
	hm.cols<-dmat.color(1-sim.data, byrank=FALSE, colors=brewer.pal(9, "PuRd"))

	# Plot and export matrix as PDF
	
	dev.new()
	pdf("Heatmap.Sim.Matrix.pdf", useDingbats=FALSE)
	plotcolors(hm.cols,rlabels=rownames(sim.data),clabels=colnames(sim.data))
	dev.off()

### HEATMAPS CRANIAL DATA

	# Subsetting data to only cranial characters

	cranial.data<-data.matrix[1:185,]

	# Calculate percentages of missing data

	perc.NA<-as.matrix(apply(cranial.data, 2, function(col)sum(is.na(col)/length(col))))

	# No taxon with 10% or more missing data present for cranial data, so nothing else done but see below for other cases

	# Make a matrix of same dimensions is which the entries are numerical

	data3<-matrix(nrow=dim(cranial.data)[1],ncol=dim(cranial.data)[2])
	for(i in 1:ncol(cranial.data)) data3[,i]<-as.numeric(cranial.data[,i])
	colnames(data3)<-colnames(cranial.data)

	# Create a similarity matrix based on 'data3' with taxa in numeric columns

	sim.data.cranial<-matrix(nrow=ncol(data3),ncol=ncol(data3))
	rownames(sim.data.cranial)<-colnames(data3)
	colnames(sim.data.cranial)<-colnames(data3)

	# Calculate smilarity values

	for(i in 1:ncol(data3)) {for(j in 1:ncol(data3)) {sim.data.cranial[j,i]<-length(grep(TRUE,data3[,j]==data3[,i]))/length(grep(TRUE,complete.cases(data3[,j]==data3[,i])))}}

	# Plot cranial similarity data as heatmap
	
	hm.cols2<-dmat.color(1-sim.data.cranial, byrank=FALSE, colors=brewer.pal(9, "PuRd"))
	dev.new()
	pdf("Heatmap.Sim.Matrix.Cranial.pdf", useDingbats=FALSE)
	plotcolors(hm.cols2,rlabels=rownames(sim.data.cranial),clabels=colnames(sim.data.cranial))
	dev.off()

### HEATMAPS SHELL DATA

	# Subsetting data to only shell characters

	shell.data<-data.matrix[186:272,]

	# Calculate percentages of missing data

	perc.NA<-as.matrix(apply(shell.data, 2, function(col)sum(is.na(col)/length(col))))
	perc.NA>=0.9

	# Create object with names of taxa with more than 90% missing data

	drop.taxa<-which(perc.NA %% 2 >= 0.9, arr.ind=TRUE, useNames=TRUE)
	drop.taxa<-attributes(drop.taxa)$dimnames[[1]]

	# Create object with numbers of columns to be dropped from dataset
	drop.cols<-which(match(colnames(shell.data), drop.taxa) != "NA")

	# Create reduced dataset that only contains taxa with more than 90% scored characters
	shell.data.red <- shell.data[,-drop.cols]

	# Make a matrix of same dimensions is which the entries are numerical

	data4<-matrix(nrow=dim(shell.data.red)[1],ncol=dim(shell.data.red)[2])
	for(i in 1:ncol(shell.data.red)) data4[,i]<-as.numeric(shell.data.red[,i])
	colnames(data4)<-colnames(shell.data.red)

	# Create a similarity matrix based on 'data4' with taxa in numeric columns

	sim.data.shell.red<-matrix(nrow=ncol(data4),ncol=ncol(data4))
	rownames(sim.data.shell.red)<-colnames(data4)
	colnames(sim.data.shell.red)<-colnames(data4)

	# Calculate smilarity values 

	for(i in 1:ncol(data4)) {for(j in 1:ncol(data4)) {sim.data.shell.red[j,i]<-length(grep(TRUE,data4[,j]==data4[,i]))/length(grep(TRUE,complete.cases(data4[,j]==data4[,i])))}}

	# Plot shell similarity data as heatmap

	hm.cols3<-dmat.color(1-sim.data.shell.red, byrank=FALSE, colors=brewer.pal(9, "PuRd"))
	dev.new()
	pdf("Heatmap.Sim.Matrix.Shell.Reduced.pdf", useDingbats=FALSE)
	plotcolors(hm.cols3,rlabels=rownames(sim.data.shell.red),clabels=colnames(sim.data.shell.red))
	dev.off()

### HEATMAPS AXIAL-GIRDLE DATA

	# Subsetting my data to only axial-girdle characters, herein 'postcranial' for shorter syntax

	postcranial.data<-data.matrix[273:322,]

	# Calculate percentages of missing data

	perc.NA<-as.matrix(apply(postcranial.data, 2, function(col)sum(is.na(col)/length(col))))
	perc.NA>=0.9

	# Create object with names of taxa with more than 90% missing data

	drop.taxa<-which(perc.NA %% 2 >= 0.9, arr.ind=TRUE, useNames=TRUE)
	drop.taxa<-attributes(drop.taxa)$dimnames[[1]]

	# Create object with numbers of columns to be dropped from dataset
	drop.cols<-which(match(colnames(postcranial.data), drop.taxa) != "NA")

	# Create reduced dataset that only contains taxa with more than 90% scored characters
	postcranial.data.red <- postcranial.data[,-drop.cols]

	# Make a matrix of same dimensions is which the entries are numerical

	data5<-matrix(nrow=dim(postcranial.data.red)[1],ncol=dim(postcranial.data.red)[2])
	for(i in 1:ncol(postcranial.data.red)) data5[,i]<-as.numeric(postcranial.data.red[,i])
	colnames(data5)<-colnames(postcranial.data.red)

	# Create a similarity matrix based on 'data5' with taxa in numeric columns

	sim.data.postcranial.red<-matrix(nrow=ncol(data5),ncol=ncol(data5))
	rownames(sim.data.postcranial.red)<-colnames(data5)
	colnames(sim.data.postcranial.red)<-colnames(data5)

	# Calculate smilarity values 

	for(i in 1:ncol(data5)) {for(j in 1:ncol(data5)) {sim.data.postcranial.red[j,i]<-length(grep(TRUE,data5[,j]==data5[,i]))/length(grep(TRUE,complete.cases(data5[,j]==data5[,i])))}}

	# Plot postcranial similarity data as heatmap

	hm.cols4<-dmat.color(1-sim.data.postcranial.red, byrank=FALSE, colors=brewer.pal(9, "PuRd"))
	dev.new()
	pdf("Heatmap.Sim.Matrix.Axial+Girdle.Reduced.pdf", useDingbats=FALSE)
	plotcolors(hm.cols4,rlabels=rownames(sim.data.postcranial.red),clabels=colnames(sim.data.postcranial.red), na.color="Lightblue")
	dev.off()

### HEATMAPS LIMB DATA

	# Subsetting data to only limb characters

	limb.data<-data.matrix[323:345,]

	# Calculate percentages of missing data

	perc.NA<-as.matrix(apply(limb.data, 2, function(col)sum(is.na(col)/length(col))))
	perc.NA>=0.9

	# Create object with names of taxa with more than 90% missing data

	drop.taxa<-which(perc.NA %% 2 >= 0.9, arr.ind=TRUE, useNames=TRUE)
	drop.taxa<-attributes(drop.taxa)$dimnames[[1]]

	# Create object with numbers of columns to be dropped from dataset
	drop.cols<-which(match(colnames(limb.data), drop.taxa) != "NA")

	# Create reduced dataset that only contains taxa with more than 90% scored characters
	limb.data.red <- limb.data[,-drop.cols]

	# Make a matrix of same dimensions is which the entries are numerical

	data6<-matrix(nrow=dim(limb.data.red)[1],ncol=dim(limb.data.red)[2])
	for(i in 1:ncol(limb.data.red)) data6[,i]<-as.numeric(limb.data.red[,i])
	colnames(data6)<-colnames(limb.data.red)

	# Create a similarity matrix based on 'data6' with taxa in numeric columns

	sim.data.limb.red<-matrix(nrow=ncol(data6),ncol=ncol(data6))
	rownames(sim.data.limb.red)<-colnames(data6)
	colnames(sim.data.limb.red)<-colnames(data6)

	# Calculate smilarity values 

	for(i in 1:ncol(data6)) {for(j in 1:ncol(data6)) {sim.data.limb.red[j,i]<-length(grep(TRUE,data6[,j]==data6[,i]))/length(grep(TRUE,complete.cases(data6[,j]==data6[,i])))}}

	# Plot limb diss data as heatmap

	hm.cols5<-dmat.color(1-sim.data.limb.red, byrank=FALSE, colors=brewer.pal(9, "PuRd"))
	dev.new()
	pdf("Heatmap.Sim.Matrix.Limb.Reduced.pdf", useDingbats=FALSE)
	plotcolors(hm.cols5,rlabels=rownames(sim.data.limb.red),clabels=colnames(sim.data.limb.red), na.color="Lightblue")
	dev.off()
