### Script used in Evers & Benson (2018) to select trees for comparisons in Templeton's tests

# Read distance matrix as matrix in which top triangle of symmetric matrix is filled with NAs, and "0"'s from 
# diagonal are changed to NAs

dist.matrix <- data.matrix(read.table("treedist_constraint20.txt", sep="\t", header=T, fill=T, na.strings="0"))
dist.matrix <- dist.matrix[,-c(1)]
rownames(dist.matrix) <- c(1:nrow(dist.matrix))
head(dist.matrix)

# Reduce the matrix so it contains only columns of the original MPTs (column argument is equal to # of original MPTs+1),
# and only the rows of the constraint MPTs (row argument is 1:# of MPTs in original analysis)
dist.matrix <- dist.matrix[-c(1:12),-c(13:ncol(dist.matrix))]
head(dist.matrix)

# Rename row names sequentially from 1
row.names(dist.matrix) <- c(1:nrow(dist.matrix))
head(dist.matrix)

# Find maximum distance value
max(dist.matrix, na.rm=TRUE)

# Define object that stores all matrix entries for which the maximum distance value is realised.
# The row number specifies the tree that should be selected from the constraint MPTs, the column number
# specifies the tree that should be selected from the original MPTs
max.dist<- data.matrix(which(dist.matrix == max(dist.matrix, na.rm=TRUE), arr.ind = TRUE))

# Sample one row (i.e constraint MPT) - column (i.e. original MPT) at random for the Templeton's test
max.dist[sample(nrow(max.dist),1),]

# Same for minimum distance 
min(dist.matrix, na.rm=TRUE)
min.dist<- data.matrix(which(dist.matrix == min(dist.matrix, na.rm=TRUE), arr.ind = TRUE))
min.dist[sample(nrow(min.dist),1),]





